<?php
// index.php - Halaman Formulir Tamu
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buku Tamu Digital - Form Tamu</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.3/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <style>
        :root {
            --teal-1: #0d9488;
            --teal-2: #14b8a6;
            --teal-light: #ecfdf5;
        }

        body {
            background-color: #f1f5f4;
            font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .page-header {
            background: linear-gradient(135deg, var(--teal-1) 0%, var(--teal-2) 60%, #5eead4 100%);
            border-radius: 0 0 24px 24px;
            padding: 40px 0 70px 0;
            margin-bottom: -50px;
            color: #fff;
            box-shadow: 0 6px 20px rgba(13, 148, 136, 0.25);
            text-align: center;
        }

        .page-header h1 {
            font-weight: 700;
            letter-spacing: 0.5px;
        }

        .page-header p {
            opacity: 0.9;
            margin-bottom: 0;
        }

        .form-wrapper {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 0 15px 40px 15px;
        }

        .form-card {
            border: none;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.06);
            width: 100%;
            max-width: 560px;
            overflow: hidden;
        }

        .form-card .card-body {
            padding: 2rem;
        }

        .form-label {
            font-weight: 600;
            color: #134e4a;
            font-size: 0.9rem;
        }

        .form-control {
            border-radius: 10px;
            border: 1px solid #d7e3e0;
            padding: 0.65rem 0.9rem;
            background-color: #f8fafa;
        }

        .form-control:focus {
            border-color: var(--teal-2);
            box-shadow: 0 0 0 0.2rem rgba(20, 184, 166, 0.15);
            background-color: #fff;
        }

        .btn-teal {
            background-color: var(--teal-1);
            border: none;
            color: #fff;
            border-radius: 10px;
            font-weight: 600;
            padding: 0.7rem 1.4rem;
            transition: 0.2s;
        }

        .btn-teal:hover {
            background-color: #0b7a70;
            color: #fff;
        }

        .info-box {
            background-color: var(--teal-light);
            border: 1px solid #d1f0ec;
            border-radius: 10px;
            padding: 0.75rem 1rem;
            color: #0f766e;
            font-size: 0.85rem;
        }

        .link-list {
            color: var(--teal-1);
            font-weight: 600;
            text-decoration: none;
        }

        .link-list:hover {
            color: #0b7a70;
            text-decoration: underline;
        }

        .icon-circle {
            width: 64px;
            height: 64px;
            border-radius: 50%;
            background-color: var(--teal-light);
            color: var(--teal-1);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.6rem;
            margin: 0 auto 0.75rem auto;
        }
    </style>
</head>
<body>

    <!-- Header Banner -->
    <div class="page-header">
        <div class="container">
            <h1 class="h3 mb-1"><i class="fa-solid fa-book-open me-2"></i>Buku Tamu Digital</h1>
            <p>Selamat datang! Silakan isi formulir kunjungan Anda</p>
        </div>
    </div>

    <div class="form-wrapper">
        <div class="form-card card mt-2">
            <div class="card-body">

                <div class="icon-circle">
                    <i class="fa-solid fa-user-pen"></i>
                </div>
                <h5 class="text-center mb-4" style="color:#134e4a; font-weight:700;">Formulir Buku Tamu</h5>

                <?php if (isset($_GET['status']) && $_GET['status'] == 'sukses') { ?>
                    <div class="alert alert-success border-0" style="background-color:#ecfdf5; color:#0f766e;" role="alert">
                        <i class="fa-solid fa-circle-check me-2"></i>
                        Data tamu berhasil disimpan. Terima kasih atas kunjungannya!
                    </div>
                <?php } ?>

                <form action="proses.php" method="POST">
                    <div class="mb-3">
                        <label for="nama" class="form-label">Nama Lengkap</label>
                        <input type="text" class="form-control" id="nama" name="nama" placeholder="Masukkan nama lengkap" required>
                    </div>

                    <div class="mb-3">
                        <label for="instansi" class="form-label">Instansi / Asal Sekolah</label>
                        <input type="text" class="form-control" id="instansi" name="instansi" placeholder="Masukkan nama instansi" required>
                    </div>

                    <div class="mb-3">
                        <label for="tujuan" class="form-label">Tujuan Kedatangan</label>
                        <textarea class="form-control" id="tujuan" name="tujuan" rows="3" placeholder="Tuliskan tujuan kedatangan" required></textarea>
                    </div>

                    <div class="info-box mb-3">
                        <i class="fa-regular fa-clock me-1"></i>
                        Tanggal dan waktu kedatangan akan dicatat otomatis oleh sistem saat formulir disubmit.
                    </div>

                    <button type="submit" class="btn btn-teal w-100">
                        <i class="fa-solid fa-paper-plane me-2"></i>Simpan Data Tamu
                    </button>
                </form>

                <div class="text-center mt-3">
                    <a href="daftar.php" class="link-list">
                        Lihat Daftar Tamu <i class="fa-solid fa-arrow-right ms-1"></i>
                    </a>
                </div>

            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.3/js/bootstrap.bundle.min.js"></script>
</body>
</html>
