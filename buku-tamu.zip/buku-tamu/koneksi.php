<?php
/**
 * koneksi.php
 * Konfigurasi koneksi database menggunakan mysqli
 */

$host = "localhost";
$user = "root";
$pass = "";
$dbname = "db_bukutamu";

// Membuat koneksi
$koneksi = mysqli_connect($host, $user, $pass, $dbname);

// Cek koneksi
if (!$koneksi) {
    die("Koneksi ke database gagal: " . mysqli_connect_error());
}

// Set charset agar mendukung karakter khusus
mysqli_set_charset($koneksi, "utf8mb4");
?>
