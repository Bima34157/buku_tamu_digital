<?php
// proses.php - Memproses dan menyimpan data form tamu ke database

include "koneksi.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // Ambil data dari form
    $nama     = mysqli_real_escape_string($koneksi, trim($_POST['nama']));
    $instansi = mysqli_real_escape_string($koneksi, trim($_POST['instansi']));
    $tujuan   = mysqli_real_escape_string($koneksi, trim($_POST['tujuan']));

    // Tanggal & waktu otomatis dari server
    $tanggal = date("Y-m-d");
    $waktu   = date("H:i:s");

    // Validasi sederhana
    if (empty($nama) || empty($instansi) || empty($tujuan)) {
        echo "Semua field wajib diisi. <a href='index.php'>Kembali</a>";
        exit;
    }

    // Query insert menggunakan prepared statement
    $query = "INSERT INTO buku_tamu (nama, instansi, tujuan, tanggal, waktu) VALUES (?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($koneksi, $query);
    mysqli_stmt_bind_param($stmt, "sssss", $nama, $instansi, $tujuan, $tanggal, $waktu);

    if (mysqli_stmt_execute($stmt)) {
        header("Location: index.php?status=sukses");
        exit;
    } else {
        echo "Terjadi kesalahan: " . mysqli_error($koneksi);
    }

    mysqli_stmt_close($stmt);
    mysqli_close($koneksi);

} else {
    header("Location: index.php");
    exit;
}
?>
