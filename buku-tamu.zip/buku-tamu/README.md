UTS Pemrograman Web II - Aplikasi Buku Tamu Digital

## Struktur File
- `koneksi.php`    : Konfigurasi koneksi database
- `index.php`      : Halaman form input tamu
- `proses.php`     : Proses simpan data ke database
- `daftar.php`     : Halaman daftar tamu + fitur pencarian
- `db_bukutamu.sql`: File struktur database & data contoh

## Cara Instalasi (XAMPP)

1. **Extract folder** `buku-tamu` ke dalam folder `htdocs` pada instalasi XAMPP
   (contoh: `C:\xampp\htdocs\buku-tamu`)

2. **Jalankan XAMPP Control Panel**, start service **Apache** dan **MySQL**

3. **Import Database**
   - Buka browser, akses `http://localhost/phpmyadmin`
   - Klik tab **Import**
   - Pilih file `db_bukutamu.sql`
   - Klik **Go**
   - Database `db_bukutamu` beserta tabel `buku_tamu` akan otomatis terbuat

4. **Cek Konfigurasi Koneksi**
   - Buka file `koneksi.php`
   - Pastikan `$host`, `$user`, `$pass`, dan `$dbname` sesuai dengan konfigurasi MySQL
   - Default XAMPP: user = `root`, password = `` (kosong)

5. **Jalankan Aplikasi**
   - Buka browser, akses: `http://localhost/buku-tamu/index.php`

## Fitur Aplikasi

### 1. Halaman Form Tamu (index.php)
- Input Nama Lengkap, Instansi, dan Tujuan Kedatangan
- Tanggal & waktu kedatangan diisi otomatis oleh sistem (server-side)
- Validasi field wajib diisi

### 2. Halaman Daftar Tamu (daftar.php)
- Menampilkan seluruh data tamu dalam tabel Bootstrap
  (table-striped, table-hover, responsive)
- Fitur pencarian berdasarkan Nama atau Instansi
- Data diurutkan dari yang terbaru

### 3. Database
- Database: `db_bukutamu`
- Tabel: `buku_tamu`
  - id (INT, AUTO_INCREMENT, PRIMARY KEY)
  - nama (VARCHAR)
  - instansi (VARCHAR)
  - tujuan (TEXT)
  - tanggal (DATE)
  - waktu (TIME)

### 4. Keamanan
- Menggunakan prepared statement (mysqli_prepare) untuk mencegah SQL Injection
- Output di-escape dengan htmlspecialchars() untuk mencegah XSS

## Catatan
- Pastikan ekstensi `mysqli` aktif di PHP (default sudah aktif di XAMPP)
- Jika ingin mengganti nama database, sesuaikan juga di file `koneksi.php` dan `db_bukutamu.sql`
