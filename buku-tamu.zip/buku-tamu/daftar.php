<?php
// daftar.php - Halaman Daftar Tamu / desain admin dashboard

include "koneksi.php";

// Ambil kata kunci pencarian (jika ada)
$keyword = isset($_GET['keyword']) ? trim($_GET['keyword']) : '';

if (!empty($keyword)) {
    $keyword_escaped = mysqli_real_escape_string($koneksi, $keyword);
    $query = "SELECT * FROM buku_tamu 
              WHERE nama LIKE '%$keyword_escaped%' 
              OR instansi LIKE '%$keyword_escaped%' 
              ORDER BY id DESC";
} else {
    $query = "SELECT * FROM buku_tamu ORDER BY id DESC";
}

$result = mysqli_query($koneksi, $query);
$jumlah = mysqli_num_rows($result);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buku Tamu Digital - Daftar Tamu</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.3/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <style>
        :root {
            --teal-1: #0d9488;
            --teal-2: #14b8a6;
            --teal-light: #ecfdf5;
        }

        body {
            background-color: #f1f5f4;
            font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
            padding-bottom: 40px;
        }

        /* Header banner */
        .page-header {
            background: linear-gradient(135deg, var(--teal-1) 0%, var(--teal-2) 60%, #5eead4 100%);
            border-radius: 0 0 24px 24px;
            padding: 40px 0 60px 0;
            margin-bottom: -40px;
            color: #fff;
            box-shadow: 0 6px 20px rgba(13, 148, 136, 0.25);
        }

        .page-header h1 {
            font-weight: 700;
            letter-spacing: 0.5px;
        }

        .page-header p {
            opacity: 0.9;
            margin-bottom: 0;
        }

        /* Main card */
        .main-card {
            border: none;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.06);
            overflow: hidden;
        }

        .main-card .card-header {
            background-color: #fff;
            border-bottom: 1px solid #eef2f1;
            padding: 1.25rem 1.5rem;
        }

        .main-card .card-header h5 {
            font-weight: 700;
            color: #134e4a;
            margin-bottom: 0;
        }

        .main-card .card-body {
            padding: 1.75rem;
        }

        /* Search form */
        .search-input {
            border-radius: 10px;
            border: 1px solid #d7e3e0;
            padding: 0.6rem 1rem 0.6rem 2.6rem;
            background-color: #f8fafa;
        }

        .search-input:focus {
            border-color: var(--teal-2);
            box-shadow: 0 0 0 0.2rem rgba(20, 184, 166, 0.15);
            background-color: #fff;
        }

        .search-wrapper {
            position: relative;
        }

        .search-wrapper i {
            position: absolute;
            top: 50%;
            left: 1rem;
            transform: translateY(-50%);
            color: #94a3a3;
        }

        .btn-teal {
            background-color: var(--teal-1);
            border: none;
            color: #fff;
            border-radius: 10px;
            font-weight: 600;
            padding: 0.6rem 1.4rem;
            transition: 0.2s;
        }

        .btn-teal:hover {
            background-color: #0b7a70;
            color: #fff;
        }

        .btn-outline-reset {
            border-radius: 10px;
            border: 1px solid #d7e3e0;
            color: #5f7370;
            font-weight: 600;
            padding: 0.6rem 1.2rem;
        }

        .btn-outline-reset:hover {
            background-color: #f1f5f4;
            color: #134e4a;
        }

        /* Table */
        .table-modern thead {
            background-color: var(--teal-light);
        }

        .table-modern thead th {
            color: #0f766e;
            font-weight: 700;
            font-size: 0.8rem;
            text-transform: uppercase;
            letter-spacing: 0.04em;
            border-bottom: none;
            padding: 0.9rem 1rem;
            white-space: nowrap;
        }

        .table-modern tbody td {
            padding: 0.9rem 1rem;
            vertical-align: middle;
            color: #334155;
            border-bottom: 1px solid #f0f4f3;
        }

        .table-modern tbody tr:hover {
            background-color: var(--teal-light);
        }

        .badge-no {
            background-color: var(--teal-light);
            color: var(--teal-1);
            font-weight: 700;
            border-radius: 8px;
            padding: 0.35em 0.7em;
            font-size: 0.8rem;
        }

        .badge-instansi {
            background-color: #e0f2fe;
            color: #0369a1;
            font-weight: 600;
            border-radius: 8px;
            padding: 0.35em 0.7em;
            font-size: 0.78rem;
            display: inline-block;
        }

        .cell-name {
            font-weight: 600;
            color: #0f172a;
        }

        .cell-tujuan {
            color: #64748b;
            font-size: 0.92rem;
            max-width: 320px;
        }

        .cell-date i, .cell-time i {
            color: var(--teal-2);
            margin-right: 6px;
        }

        .info-text {
            color: #64748b;
            font-size: 0.9rem;
        }

        .empty-state {
            text-align: center;
            padding: 50px 20px;
            color: #94a3a3;
        }

        .empty-state i {
            font-size: 2.5rem;
            color: #cbd5d5;
            margin-bottom: 10px;
            display: block;
        }

        .btn-back {
            border-radius: 10px;
            font-weight: 600;
            padding: 0.6rem 1.6rem;
            border: 1px solid #d7e3e0;
            color: #5f7370;
            background-color: #fff;
        }

        .btn-back:hover {
            background-color: #f1f5f4;
            color: #134e4a;
        }
    </style>
</head>
<body>

    <!-- Header Banner -->
    <div class="page-header">
        <div class="container">
            <h1 class="h3 mb-1"><i class="fa-solid fa-book-open me-2"></i>Buku Tamu Digital</h1>
            <p>Daftar tamu yang telah berkunjung ke sekolah</p>
        </div>
    </div>

    <div class="container">
        <div class="main-card card mt-2">
            <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
                <h5><i class="fa-solid fa-list-ul me-2 text-success"></i>Daftar Tamu</h5>
                <a href="index.php" class="btn btn-back btn-sm">
                    <i class="fa-solid fa-arrow-left me-1"></i> Form Tamu
                </a>
            </div>

            <div class="card-body">

                <!-- Form Pencarian -->
                <form action="daftar.php" method="GET" class="row g-2 mb-4 align-items-center">
                    <div class="col-md-9 col-sm-8">
                        <div class="search-wrapper">
                            <i class="fa-solid fa-magnifying-glass"></i>
                            <input type="text" name="keyword" class="form-control search-input"
                                   placeholder="Cari berdasarkan nama atau instansi..."
                                   value="<?php echo htmlspecialchars($keyword); ?>">
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-4 d-flex gap-2">
                        <button type="submit" class="btn btn-teal flex-fill">
                            <i class="fa-solid fa-magnifying-glass me-1"></i> Cari
                        </button>
                        <?php if (!empty($keyword)) { ?>
                            <a href="daftar.php" class="btn btn-outline-reset flex-fill">Reset</a>
                        <?php } ?>
                    </div>
                </form>

                <?php if (!empty($keyword)) { ?>
                    <p class="info-text mb-3">
                        Menampilkan <strong><?php echo $jumlah; ?></strong> hasil untuk pencarian
                        "<strong><?php echo htmlspecialchars($keyword); ?></strong>"
                    </p>
                <?php } ?>

                <!-- Tabel Data Tamu -->
                <?php if ($jumlah > 0) { ?>
                <div class="table-responsive">
                    <table class="table table-modern align-middle mb-0">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Nama Lengkap</th>
                                <th>Instansi</th>
                                <th>Tujuan Kedatangan</th>
                                <th>Tanggal</th>
                                <th>Waktu</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $no = 1;
                            while ($row = mysqli_fetch_assoc($result)) { ?>
                                <tr>
                                    <td><span class="badge-no">#<?php echo $no++; ?></span></td>
                                    <td class="cell-name"><?php echo htmlspecialchars($row['nama']); ?></td>
                                    <td><span class="badge-instansi"><?php echo htmlspecialchars($row['instansi']); ?></span></td>
                                    <td class="cell-tujuan"><?php echo htmlspecialchars($row['tujuan']); ?></td>
                                    <td class="cell-date"><i class="fa-regular fa-calendar"></i><?php echo date("d-m-Y", strtotime($row['tanggal'])); ?></td>
                                    <td class="cell-time"><i class="fa-regular fa-clock"></i><?php echo $row['waktu']; ?></td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
                <?php } else { ?>
                    <div class="empty-state">
                        <i class="fa-regular fa-folder-open"></i>
                        <p class="mb-0">Belum ada data tamu yang tercatat.</p>
                    </div>
                <?php } ?>

            </div>
        </div>

        <p class="text-center info-text mt-3 mb-0">
            &copy; <?php echo date("Y"); ?> Buku Tamu Digital Sekolah
        </p>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.3/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php mysqli_close($koneksi); ?>
